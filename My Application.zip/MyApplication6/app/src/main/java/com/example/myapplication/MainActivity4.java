package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String e;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        TextView y=findViewById(R.id.textView6);
        TextView h=findViewById(R.id.textView9);
        e=String.valueOf(MainActivity3.b);
        if(e.equals("0"))
        {
            h.setText("Bad");
        }
        else if(e.equals("1"))
        {
            h.setText("Average");
        }
        else
        {
            h.setText("Good");
        }

        y.setText(e+"/2");
    }
}