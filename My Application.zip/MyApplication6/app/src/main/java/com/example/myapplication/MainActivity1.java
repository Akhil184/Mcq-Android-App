package com.example.myapplication;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {
    TextView h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menud,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        h=(TextView)findViewById(R.id.textView2);
            if(item.getItemId()==R.id.a) {
                Intent u=new Intent(getApplicationContext(),MainActivity2.class);
                startActivity(u);
                return true;
            }
            else if(item.getItemId()==R.id.p) {
                Intent y=new Intent(Intent.ACTION_VIEW);
                y.setData(Uri.parse("https://www.youtube.com/watch?v=NGGNH69goUU"));
                startActivity(y);
                return true;
            }
            else if(item.getItemId()==R.id.k) {
                h.setText("excellent");
                return true;
            }
            else
            {
                return super.onOptionsItemSelected(item);
        }
        }
        }



