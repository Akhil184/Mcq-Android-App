package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class MainActivity2 extends AppCompatActivity {
    public static int counter, count = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button readButton;
        TextView editTextData = findViewById(R.id.editText2);
        Button saveButton = findViewById(R.id.button1);


        readButton = findViewById(R.id.button2);
        TextView f = findViewById(R.id.textView5);

        new CountDownTimer(8000, 1000) {
            public void onTick(long millisUntilFinished) {
                editTextData.setText(String.valueOf(counter));
                counter++;
            }

            public void onFinish() {
                 Intent ety = new Intent(MainActivity2.this, MainActivity3.class);
                //intent.putExtra("EXTRA_SESSION_ID", count);
                startActivity(ety);
            }
        }.start();

        //Performing Action on Read Button

    }

    public void onRadioButtonClicked(View view) {
        boolean p = ((RadioButton) view).isChecked();
        TextView editTextData = findViewById(R.id.editText2);
        Button saveButton = findViewById(R.id.button1);

        switch (view.getId()) {
            case R.id.radioButton:
                if (p) {
                    MainActivity2.count = MainActivity2.count + 1;
                    break;
                }
            case R.id.radioButton2:
                if(p){
                    MainActivity2.count=0;
                }
            case R.id.radioButton3:
                if(p){
                    MainActivity2.count=0;
                }
        }
    }
        public void action (View view){
            Intent ety = new Intent(MainActivity2.this, MainActivity3.class);
            //intent.putExtra("EXTRA_SESSION_ID", count);
            startActivity(ety);
        }
    }


