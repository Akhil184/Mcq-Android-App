package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import com.example.myapplication.MainActivity2;

//import static com.example.myapplication.MainActivity2.count;


public class MainActivity3 extends AppCompatActivity {
    //int count = Integer.parseInt(getIntent().getStringExtra("EXTRA_SESSION_ID"));

    public static int b,counh=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TextView b = findViewById(R.id.textView5);
        //b.setText(count);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        TextView y = findViewById(R.id.textView7);


        new CountDownTimer(8000, 1000) {
            public void onTick(long millisUntilFinished) {
                y.setText(String.valueOf(MainActivity2.counter));
                MainActivity2.counter++;
            }

            public void onFinish() {
                Intent ety = new Intent(MainActivity3.this, MainActivity4.class);
                //intent.putExtra("EXTRA_SESSION_ID", count);
                startActivity(ety);
            }
        }.start();

    }
    public void act(View view) {
        boolean p = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radioButton4:
                if (p) {
                    MainActivity2.count=MainActivity2.count+1;
                    b=MainActivity2.count;//MainActivity2.count=MainActivity2.count+1;
                }
            case R.id.radioButton5:
                if (p) {
                    //MainActivity2.count=MainActivity2.count+1;
                    b=MainActivity2.count;//MainActivity2.count=MainActivity2.count+1;
                }
            case R.id.radioButton6:
                if (p) {
                    //MainActivity2.count=MainActivity2.count+1;
                    b=MainActivity2.count;//MainActivity2.count=MainActivity2.count+1;
                }

        }


    }

    public void wt(View view) {
        //Button d=findViewById(R.id.button3);
        Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
        //intent.putExtra("EXTRA_SESSION_ID", count);
        startActivity(intent);
    }
    public void v(View view) {
        //Button d=findViewById(R.id.button3);
        Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
        //intent.putExtra("EXTRA_SESSION_ID", count);
        startActivity(intent);
    }


}